% Paper: Convex-Concave Tensor Robust Principal Component Analysis (Journal��IJCV)
% Algorithm: CCSVS 
% Writer: Youfa Liu

file_path =strcat(pwd,'\Test\');
img_path_list = dir(strcat(file_path,'*.jpg'));
img_num = length(img_path_list);
psnr_record=[];

if img_num > 0 
         for j = 1
            image_name = img_path_list(j).name;
            image =imread(strcat(file_path,image_name));

X = double(image);
X = X/255;

maxP = max(abs(X(:)));
[n1,n2,n3] = size(X);
Xn = X;
rhos = 0.1;

RAND1=rand(n1*n2*n3,1);
ind = find(RAND1<rhos);
ind = find(rand(n1*n2*n3,1)<rhos);
RAND2=rand(length(ind),1);
% Generate 10% noisy data randomly
Xn(ind) = RAND2;

opts.mu = 1e-2;
opts.tol = 1e-5;
opts.rho = 1.1;
opts.max_iter = 500;
opts.DEBUG = 1;

ll=min(n1,n2);
% Set P for singular value separation
P=45;
% Set weights for convex-concave signualr value separation
opts.w=[linspace(-1e-5,-1e-7,P)';0.7*ones(ll-P,1)];
opts.P=P;
% Set sclice weights
opts.Slice_weights=[0.55,1.55*ones(1,n3-1)];

[n1,n2,n3] = size(Xn);
lambda = 1/sqrt(max(n1,n2)*n3);

[Xhat,E,err,iter] = trpca_tnn(Xn,lambda,opts);

% r=tubalrank(Xhat)
Xhat = max(Xhat,0);
Xhat = min(Xhat,maxP);
psnr = PSNR(X,Xhat,maxP)

figure(1)
subplot(1,3,1)
imshow(X/max(X(:)))
subplot(1,3,2)
imshow(Xn/max(Xn(:)))
subplot(1,3,3)
imshow(Xhat/max(Xhat(:)))

psnr_record=[psnr_record,psnr]

         end
end
